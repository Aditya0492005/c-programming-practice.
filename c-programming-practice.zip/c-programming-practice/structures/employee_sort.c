#include <stdio.h>

struct Employee {
    int id;
    char name[50];
    float salary;
};

int main() {
    struct Employee e[100], temp;
    int n;

    printf("Enter number of employees: ");
    scanf("%d", &n);

    if (n <= 0 || n > 100) {
        printf("Invalid number of employees.\n");
        return 1;
    }

    for (int i = 0; i < n; i++) {
        printf("\nEmployee %d\n", i + 1);

        printf("Enter ID: ");
        scanf("%d", &e[i].id);

        printf("Enter Name: ");
        scanf(" %49[^\n]", e[i].name);

        printf("Enter Salary: ");
        scanf("%f", &e[i].salary);
    }

    // Sort by salary in descending order
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (e[i].salary < e[j].salary) {
                temp = e[i];
                e[i] = e[j];
                e[j] = temp;
            }
        }
    }

    printf("\n--- Employees Sorted by Salary (Descending) ---\n");
    for (int i = 0; i < n; i++) {
        printf("ID: %d | Name: %s | Salary: %.2f\n",
               e[i].id, e[i].name, e[i].salary);
    }

    return 0;
}
