# C Programming Practice

A collection of beginner-friendly C programs covering basic programming concepts, arrays, searching, and structures.

## Contents
- Basics: Hello World, Calculator, Factorial
- Arrays: Largest Element, Reverse Array
- Searching: Binary Search
- Structures: Student Record, Employee Salary Sorting

## Requirements
- GCC or another C compiler
- Any code editor or IDE

## Compile and Run
```bash
gcc filename.c -o program
./program
```

On Windows:
```bash
gcc filename.c -o program.exe
program.exe
```

## Topics Covered
- Variables and data types
- Input/Output
- Conditional statements
- Loops
- Arrays
- Searching
- Structures
- Sorting

**Language:** C  
**Level:** Beginner
