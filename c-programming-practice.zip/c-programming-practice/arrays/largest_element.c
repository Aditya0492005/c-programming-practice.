#include <stdio.h>

int main() {
    int n, a[100];

    printf("Enter number of elements: ");
    scanf("%d", &n);

    if (n <= 0 || n > 100) {
        printf("Invalid size.\n");
        return 1;
    }

    printf("Enter %d elements: ", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }

    int largest = a[0];
    for (int i = 1; i < n; i++) {
        if (a[i] > largest)
            largest = a[i];
    }

    printf("Largest element = %d\n", largest);
    return 0;
}
